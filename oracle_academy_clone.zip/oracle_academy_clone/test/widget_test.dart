import 'package:flutter_test/flutter_test.dart';
import 'package:oracle_academy_clone/main.dart';

void main() {
  testWidgets('App renders without errors', (WidgetTester tester) async {
    await tester.pumpWidget(const OracleAcademyApp());
    expect(find.text('Oracle Academy'), findsOneWidget);
  });
}
