import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'carousel_dots.dart';

/// Hero banner con Stack: imagen de fondo + overlay gradiente + texto + dots.
class HeroBanner extends StatelessWidget {
  const HeroBanner({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return SizedBox(
      height: 520,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // ── Capa 1: Imagen de fondo ──
          Image.asset(
            'assets/images/hero_bg.png',
            fit: BoxFit.cover,
          ),
          // ── Capa 2: Overlay con gradiente oscuro ──
          _buildOverlay(),
          // ── Capa 3: Contenido de texto ──
          _buildTextContent(theme),
          // ── Capa 4: Dots del carrusel ──
          const Positioned(
            bottom: AppTheme.spacing32,
            left: 0,
            right: 0,
            child: Center(child: CarouselDots()),
          ),
        ],
      ),
    );
  }

  Widget _buildOverlay() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [
            AppTheme.heroOverlay.withValues(alpha: 0.7),
            AppTheme.heroOverlay.withValues(alpha: 0.3),
          ],
        ),
      ),
    );
  }

  Widget _buildTextContent(ThemeData theme) {
    return Positioned(
      left: AppTheme.spacing64,
      top: AppTheme.spacing64,
      right: MediaQueryData.fromView(
              WidgetsBinding.instance.platformDispatcher.views.first)
          .size
          .width *
          0.4,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: AppTheme.spacing48),
          Text(
            'Explore our new data\ncenter-focused curriculum!',
            style: theme.textTheme.displayLarge,
          ),
          const SizedBox(height: AppTheme.spacing24),
          Text(
            'Especially for vocational/technical learning, we now offer Data Center Operations Foundations and Data Center Technician Foundations 1 and 2 to help prepare the next generation with career-ready, industry-aligned knowledge and skills.',
            style: theme.textTheme.bodyLarge,
          ),
          const SizedBox(height: AppTheme.spacing32),
          _buildLearnMoreButton(theme),
        ],
      ),
    );
  }

  Widget _buildLearnMoreButton(ThemeData theme) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppTheme.spacing24,
        vertical: AppTheme.spacing12,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppTheme.spacing4),
      ),
      child: Text(
        'Learn More',
        style: theme.textTheme.labelLarge?.copyWith(
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
