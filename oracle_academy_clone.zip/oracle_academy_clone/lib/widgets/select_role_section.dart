import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'role_card.dart';

/// Sección "Select Your Role" con fondo teal.
/// Column: [Título] + [Descripción] + [Row de 3 RoleCards separadas por divisores]
class SelectRoleSection extends StatelessWidget {
  const SelectRoleSection({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      width: double.infinity,
      color: AppTheme.roleBackground,
      padding: const EdgeInsets.symmetric(
        vertical: AppTheme.spacing48,
        horizontal: AppTheme.spacing64,
      ),
      child: Column(
        children: [
          // ── Título ──
          Text(
            'Select Your Role',
            style: theme.textTheme.headlineLarge?.copyWith(
              color: AppTheme.roleOnBackground,
            ),
          ),
          const SizedBox(height: AppTheme.spacing16),
          // ── Descripción ──
          Text(
            'Oracle Academy works with institutions, educators, and partners across the globe to help millions of students become technology innovators and leaders.',
            style: theme.textTheme.bodyMedium,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: AppTheme.spacing48),
          // ── Row de 3 cards con divisores ──
          _buildRoleCards(),
        ],
      ),
    );
  }

  Widget _buildRoleCards() {
    return IntrinsicHeight(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          const Expanded(
            child: RoleCard(
              imagePath: 'assets/images/role_institutions.png',
              label: 'Institutions and Educators',
            ),
          ),
          _buildDivider(),
          const Expanded(
            child: RoleCard(
              imagePath: 'assets/images/role_collaborators.png',
              label: 'Collaborators',
            ),
          ),
          _buildDivider(),
          const Expanded(
            child: RoleCard(
              imagePath: 'assets/images/role_learners.png',
              label: 'Learners',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDivider() {
    return Container(
      width: 1,
      margin: const EdgeInsets.symmetric(vertical: AppTheme.spacing16),
      color: AppTheme.roleOnBackground.withValues(alpha: 0.3),
    );
  }
}
