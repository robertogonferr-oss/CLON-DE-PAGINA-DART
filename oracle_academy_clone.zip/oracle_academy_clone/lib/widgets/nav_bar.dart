import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Barra de navegación superior estilo Oracle Academy.
/// Row principal: [Logo + Hamburguesa]  ─── Spacer ───  [Search, SignIn, Language, Help]
class NavBar extends StatelessWidget {
  const NavBar({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      color: theme.colorScheme.surface,
      padding: const EdgeInsets.symmetric(
        horizontal: AppTheme.spacing24,
        vertical: AppTheme.spacing12,
      ),
      child: Row(
        children: [
          // ── Logo Oracle Academy ──
          _buildLogo(theme),
          const SizedBox(width: AppTheme.spacing16),
          // ── Menú hamburguesa ──
          Icon(Icons.menu, color: theme.colorScheme.onSurface, size: 24),
          const Spacer(),
          // ── Acciones de la derecha ──
          _buildNavActions(theme),
        ],
      ),
    );
  }

  Widget _buildLogo(ThemeData theme) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Icono Oracle (círculo simplificado)
        Container(
          width: 32,
          height: 20,
          decoration: BoxDecoration(
            border: Border.all(
              color: theme.colorScheme.onSurface,
              width: 2,
            ),
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        const SizedBox(width: AppTheme.spacing8),
        Text(
          'Oracle Academy',
          style: theme.textTheme.labelLarge?.copyWith(
            fontWeight: FontWeight.w600,
            fontSize: 16,
          ),
        ),
      ],
    );
  }

  Widget _buildNavActions(ThemeData theme) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _NavAction(icon: Icons.search, label: 'Search', theme: theme),
        const SizedBox(width: AppTheme.spacing24),
        _NavAction(icon: Icons.person_outline, label: 'Sign In', theme: theme),
        const SizedBox(width: AppTheme.spacing24),
        _NavAction(icon: Icons.language, label: 'Language', theme: theme),
        const SizedBox(width: AppTheme.spacing24),
        _NavAction(icon: Icons.help_outline, label: 'Help', theme: theme),
      ],
    );
  }
}

class _NavAction extends StatelessWidget {
  const _NavAction({
    required this.icon,
    required this.label,
    required this.theme,
  });

  final IconData icon;
  final String label;
  final ThemeData theme;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(label, style: theme.textTheme.labelLarge),
        const SizedBox(width: AppTheme.spacing4),
        Icon(icon, color: theme.colorScheme.onSurface, size: 20),
      ],
    );
  }
}
