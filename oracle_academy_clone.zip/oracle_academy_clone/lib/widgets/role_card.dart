import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Card individual de rol con imagen circular + texto.
/// Column: [CircleAvatar con imagen] + [Texto del rol]
class RoleCard extends StatelessWidget {
  const RoleCard({
    super.key,
    required this.imagePath,
    required this.label,
  });

  final String imagePath;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // ── Imagen circular ──
        ClipOval(
          child: Image.asset(
            imagePath,
            width: 160,
            height: 160,
            fit: BoxFit.cover,
          ),
        ),
        const SizedBox(height: AppTheme.spacing24),
        // ── Etiqueta del rol ──
        Text(
          label,
          style: Theme.of(context).textTheme.titleMedium,
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
