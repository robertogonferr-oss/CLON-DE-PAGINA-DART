import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Indicadores de puntos del carrusel.
/// Row de círculos: uno activo (blanco sólido) y el resto inactivos (blanco 50%).
class CarouselDots extends StatelessWidget {
  const CarouselDots({
    super.key,
    this.total = 6,
    this.activeIndex = 0,
  });

  final int total;
  final int activeIndex;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Flecha izquierda
        Icon(Icons.chevron_left, color: AppTheme.dotActive, size: 32),
        const SizedBox(width: AppTheme.spacing8),
        // Dots
        ...List.generate(total, (index) {
          final isActive = index == activeIndex;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppTheme.spacing4),
            child: Container(
              width: isActive ? 12 : 8,
              height: isActive ? 12 : 8,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isActive ? AppTheme.dotActive : AppTheme.dotInactive,
              ),
            ),
          );
        }),
        const SizedBox(width: AppTheme.spacing8),
        // Flecha derecha
        Icon(Icons.chevron_right, color: AppTheme.dotActive, size: 32),
      ],
    );
  }
}
