import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Footer con fondo oscuro.
/// Row: [Logo Oracle Academy] + [© + links (Wrap)] + [Íconos sociales (Row)]
class AppFooter extends StatelessWidget {
  const AppFooter({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      width: double.infinity,
      color: AppTheme.footerBackground,
      padding: const EdgeInsets.symmetric(
        horizontal: AppTheme.spacing32,
        vertical: AppTheme.spacing24,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // ── Logo Oracle Academy ──
          _buildFooterLogo(theme),
          const SizedBox(width: AppTheme.spacing32),
          // ── Copyright + links ──
          Expanded(child: _buildFooterLinks(theme)),
          // ── Redes sociales ──
          _buildSocialIcons(),
        ],
      ),
    );
  }

  Widget _buildFooterLogo(ThemeData theme) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          'ORACLE',
          style: theme.textTheme.bodySmall?.copyWith(
            color: AppTheme.footerLink,
            fontWeight: FontWeight.w700,
            fontSize: 16,
            letterSpacing: 4,
          ),
        ),
        Text(
          'Academy',
          style: theme.textTheme.bodySmall?.copyWith(
            color: AppTheme.footerLink,
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Widget _buildFooterLinks(ThemeData theme) {
    const links = [
      '© 2026, Oracle and/or its affiliates.',
      'Site Map',
      'Contact Us',
      'Member Agreement',
      'Terms of Use',
      'Privacy',
      'Accessibility',
      'Cookie Preferences',
      'About Oracle',
    ];

    return Wrap(
      spacing: AppTheme.spacing16,
      runSpacing: AppTheme.spacing4,
      children: links.map((link) {
        return Text(
          link,
          style: theme.textTheme.bodySmall?.copyWith(
            color: AppTheme.footerLink,
          ),
        );
      }).toList(),
    );
  }

  Widget _buildSocialIcons() {
    const socialIcons = [
      Icons.facebook,
      Icons.alternate_email,     // Twitter/X
      Icons.camera_alt_outlined, // Instagram
      Icons.play_circle_outline, // YouTube
      Icons.article_outlined,    // Blog
    ];

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: socialIcons.map((icon) {
        return Padding(
          padding: const EdgeInsets.only(left: AppTheme.spacing12),
          child: Icon(icon, color: AppTheme.footerLink, size: 20),
        );
      }).toList(),
    );
  }
}
