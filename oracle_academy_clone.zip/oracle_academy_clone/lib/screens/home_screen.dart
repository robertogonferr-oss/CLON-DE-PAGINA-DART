import 'package:flutter/material.dart';
import '../widgets/nav_bar.dart';
import '../widgets/hero_banner.dart';
import '../widgets/select_role_section.dart';
import '../widgets/footer.dart';

/// Pantalla principal que ensambla las 4 secciones en un SingleChildScrollView.
/// Column: [NavBar] + [HeroBanner] + [SelectRoleSection] + [Footer]
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            NavBar(),
            HeroBanner(),
            SelectRoleSection(),
            AppFooter(),
          ],
        ),
      ),
    );
  }
}
