import 'package:flutter/material.dart';

/// Tema centralizado de la app — cero valores crudos.
/// Todos los colores y estilos se consumen con Theme.of(context).
class AppTheme {
  AppTheme._();

  // ── Paleta Oracle Academy ────────────────────────────────────
  static const Color _oracleRed = Color(0xFFC74634);
  static const Color _navSurface = Color(0xFFFFFFFF);
  static const Color _navText = Color(0xFF1A1A1A);
  static const Color _heroOverlay = Color(0x80000000);
  static const Color _roleBackground = Color(0xFF3B8C8C);
  static const Color _roleOnBackground = Color(0xFFFFFFFF);
  static const Color _footerBackground = Color(0xFF1A1A1A);
  static const Color _footerText = Color(0xFF999999);
  static const Color _footerLink = Color(0xFFCCCCCC);
  static const Color _dotActive = Color(0xFFFFFFFF);
  static const Color _dotInactive = Color(0x80FFFFFF);

  // ── Acceso público a colores personalizados ──────────────────
  static Color get heroOverlay => _heroOverlay;
  static Color get roleBackground => _roleBackground;
  static Color get roleOnBackground => _roleOnBackground;
  static Color get footerBackground => _footerBackground;
  static Color get footerText => _footerText;
  static Color get footerLink => _footerLink;
  static Color get dotActive => _dotActive;
  static Color get dotInactive => _dotInactive;
  static Color get oracleRed => _oracleRed;

  // ── Rejilla de 4 px ──────────────────────────────────────────
  static const double spacing4 = 4;
  static const double spacing8 = 8;
  static const double spacing12 = 12;
  static const double spacing16 = 16;
  static const double spacing24 = 24;
  static const double spacing32 = 32;
  static const double spacing48 = 48;
  static const double spacing64 = 64;

  // ── ThemeData ────────────────────────────────────────────────
  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      fontFamily: 'Segoe UI',
      colorScheme: const ColorScheme.light(
        primary: _oracleRed,
        surface: _navSurface,
        onSurface: _navText,
      ),
      scaffoldBackgroundColor: _navSurface,
      appBarTheme: const AppBarTheme(
        backgroundColor: _navSurface,
        foregroundColor: _navText,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
      ),
      textTheme: const TextTheme(
        // Hero title
        displayLarge: TextStyle(
          fontSize: 48,
          fontWeight: FontWeight.w300,
          color: Colors.white,
          height: 1.15,
        ),
        // Section title (Select Your Role)
        headlineLarge: TextStyle(
          fontSize: 32,
          fontWeight: FontWeight.w400,
          color: _navText,
          height: 1.3,
        ),
        // Card labels
        titleMedium: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w700,
          color: _roleOnBackground,
        ),
        // Body hero
        bodyLarge: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w400,
          color: Colors.white,
          height: 1.5,
        ),
        // Body section
        bodyMedium: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w700,
          color: _roleOnBackground,
          height: 1.5,
        ),
        // Footer / nav links
        bodySmall: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w400,
          color: _footerText,
        ),
        // Nav bar items
        labelLarge: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w400,
          color: _navText,
        ),
      ),
    );
  }
}
